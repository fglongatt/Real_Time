// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------

#include "math.h"
#include <stdint.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"

// H files from Advanced C Function components

// Header files from additional sources (Advanced C Function)
// ----------------------------------------------------------------------------------------
// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines









//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables


//@cmp.var.start
// variables
double _d__out;
double _dpload__out;
double _dpmec__out = 0.0;
double _sum2__out;
double _sum1__out;
double _m__out;
double _m__b_coeff[1] = {1.666666666666483e-05};
double _m__a_coeff[2] = {1.0, -1.0};
double _m__a_sum;
double _m__b_sum;
double _m__delay_line_in;
X_UnInt32 _m__i;
//@cmp.var.end

//@cmp.svar.start
// state variables
double _dpload__current_phase;
double _m__states[1];
//@cmp.svar.end





// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _dpload__current_phase = 0.0;
    HIL_OutAO(0x2002, 0.0f);
    HIL_OutAO(0x2000, 0.0f);
    HIL_OutAO(0x2001, 0.0f);
    for (_m__i = 0; _m__i < 1; _m__i++) {
        _m__states[_m__i] = 0;
    }
    //@cmp.init.block.end
}

void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}

void init_fmu_objects_cpu0_dev0(void) {
    return;
}


void terminate_fmu_objects_cpu0_dev0(void) {
    return;
}
// generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) ((value > limit) ? value : limit)
#endif
#ifndef MIN
#define MIN(value, limit) ((value < limit) ? value : limit)
#endif

// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: D
    _d__out = 0.66 * _m__out;
    // Generated from the component: dPload
    if (_dpload__current_phase < 0.5) {
        _dpload__out = 0.05;
    } else {
        _dpload__out = 0.0;
    }
    // Generated from the component: dPmec
    // Generated from the component: df
    HIL_OutAO(0x2002, (float)_m__out);
    // Generated from the component: Sum2
    _sum2__out = _dpload__out + _d__out;
    // Generated from the component: dPL
    HIL_OutAO(0x2000, (float)_dpload__out);
    // Generated from the component: Sum1
    _sum1__out = _dpmec__out - _sum2__out;
    // Generated from the component: dPe
    HIL_OutAO(0x2001, (float)_sum2__out);
    // Generated from the component: M
    _m__a_sum = 0.0f;
    _m__b_sum = 0.0f;
    _m__delay_line_in = 0.0f;
    for (_m__i = 0; _m__i < 1; _m__i++) {
        _m__b_sum += _m__b_coeff[_m__i] * _m__states[_m__i + 0];
    }
    _m__a_sum += _m__states[0] * _m__a_coeff[1];
    _m__delay_line_in = _sum1__out - _m__a_sum;
    _m__out = _m__b_sum;
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: dPload
    _dpload__current_phase += 0.01 * 0.0001;
    if (_dpload__current_phase >= 1.0f) {
        _dpload__current_phase -= 1.0f;
    }
    // Generated from the component: M
    _m__states[0] = _m__delay_line_in;
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------