// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------

#include "math.h"
#include <stdint.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"

// H files from Advanced C Function components

// Header files from additional sources (Advanced C Function)
// ----------------------------------------------------------------------------------------
// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines








//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables


//@cmp.var.start
// variables
double _ia1_ia1__out;
double _va1_va1__out;
double _rms_value1__out;
double _rms_value1__previous_value;
double _rms_value1__previous_filtered_value;
double _rms_value1__correction;
double _rms_value1__previous_correction;
X_UnInt32 _rms_value1__zc;
double _rms_value2__out;
double _rms_value2__previous_value;
double _rms_value2__previous_filtered_value;
double _rms_value2__correction;
double _rms_value2__previous_correction;
X_UnInt32 _rms_value2__zc;
//@cmp.var.end

//@cmp.svar.start
// state variables
double _rms_value1__square_sum;
double _rms_value1__sample_cnt;
double _rms_value1__filtered_value;
double _rms_value1__out_state;
double _rms_value2__square_sum;
double _rms_value2__sample_cnt;
double _rms_value2__filtered_value;
double _rms_value2__out_state;
//@cmp.svar.end





// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _rms_value1__square_sum = 0x0;
    _rms_value1__sample_cnt = 0x0;
    _rms_value1__filtered_value = 0x0;
    _rms_value1__out_state = 0x0;
    HIL_OutAO(0x2002, 0.0f);
    _rms_value2__square_sum = 0x0;
    _rms_value2__sample_cnt = 0x0;
    _rms_value2__filtered_value = 0x0;
    _rms_value2__out_state = 0x0;
    HIL_OutAO(0x2003, 0.0f);
    HIL_OutAO(0x2000, 0.0f);
    HIL_OutAO(0x2001, 0.0f);
    //@cmp.init.block.end
}

void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}

void init_fmu_objects_cpu0_dev0(void) {
    return;
}


void terminate_fmu_objects_cpu0_dev0(void) {
    return;
}
// generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) ((value > limit) ? value : limit)
#endif
#ifndef MIN
#define MIN(value, limit) ((value < limit) ? value : limit)
#endif

// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Ia1.Ia1
    _ia1_ia1__out = (HIL_InFloat(0xc80000 + 0x2));
    // Generated from the component: Va1.Va1
    _va1_va1__out = (HIL_InFloat(0xc80000 + 0x1));
    // Generated from the component: RMS value1
    _rms_value1__previous_filtered_value = _rms_value1__filtered_value;
    _rms_value1__filtered_value = _rms_value1__previous_filtered_value * 0.1 + _ia1_ia1__out * 0.9;
    if( (_rms_value1__filtered_value >= 0.0) && (_rms_value1__previous_filtered_value < 0.0) )
        _rms_value1__zc = 1;
    else
        _rms_value1__zc = 0;
    _rms_value1__out = _rms_value1__out_state;
    // Generated from the component: i
    HIL_OutAO(0x2002, (float)_ia1_ia1__out);
    // Generated from the component: RMS value2
    _rms_value2__previous_filtered_value = _rms_value2__filtered_value;
    _rms_value2__filtered_value = _rms_value2__previous_filtered_value * 0.1 + _va1_va1__out * 0.9;
    if( (_rms_value2__filtered_value >= 0.0) && (_rms_value2__previous_filtered_value < 0.0) )
        _rms_value2__zc = 1;
    else
        _rms_value2__zc = 0;
    _rms_value2__out = _rms_value2__out_state;
    // Generated from the component: vl
    HIL_OutAO(0x2003, (float)_va1_va1__out);
    // Generated from the component: Irms
    HIL_OutAO(0x2000, (float)_rms_value1__out);
    // Generated from the component: VLrms
    HIL_OutAO(0x2001, (float)_rms_value2__out);
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: RMS value1
    if( _rms_value1__zc ) {
        if (_ia1_ia1__out != _rms_value1__previous_value)
            _rms_value1__correction = - _rms_value1__previous_value / (_ia1_ia1__out - _rms_value1__previous_value);
        if (_rms_value1__correction < 0)
            _rms_value1__correction = 0;
        else
            _rms_value1__correction = 0;
        _rms_value1__sample_cnt += _rms_value1__correction - _rms_value1__previous_correction;
        _rms_value1__out_state = sqrt(_rms_value1__square_sum / _rms_value1__sample_cnt);
        _rms_value1__sample_cnt = 0;
        _rms_value1__previous_correction = _rms_value1__correction;
        _rms_value1__square_sum = 0;
    } else if ( _rms_value1__sample_cnt >= 5000 ) {
        _rms_value1__out_state = sqrt(_rms_value1__square_sum / _rms_value1__sample_cnt);
        _rms_value1__sample_cnt = 0;
        _rms_value1__square_sum = 0;
    }
    _rms_value1__previous_value = _ia1_ia1__out;
    _rms_value1__square_sum += _ia1_ia1__out * _ia1_ia1__out;
    _rms_value1__sample_cnt ++;
    // Generated from the component: RMS value2
    if( _rms_value2__zc ) {
        if (_va1_va1__out != _rms_value2__previous_value)
            _rms_value2__correction = - _rms_value2__previous_value / (_va1_va1__out - _rms_value2__previous_value);
        if (_rms_value2__correction < 0)
            _rms_value2__correction = 0;
        else
            _rms_value2__correction = 0;
        _rms_value2__sample_cnt += _rms_value2__correction - _rms_value2__previous_correction;
        _rms_value2__out_state = sqrt(_rms_value2__square_sum / _rms_value2__sample_cnt);
        _rms_value2__sample_cnt = 0;
        _rms_value2__previous_correction = _rms_value2__correction;
        _rms_value2__square_sum = 0;
    } else if ( _rms_value2__sample_cnt >= 5000 ) {
        _rms_value2__out_state = sqrt(_rms_value2__square_sum / _rms_value2__sample_cnt);
        _rms_value2__sample_cnt = 0;
        _rms_value2__square_sum = 0;
    }
    _rms_value2__previous_value = _va1_va1__out;
    _rms_value2__square_sum += _va1_va1__out * _va1_va1__out;
    _rms_value2__sample_cnt ++;
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------